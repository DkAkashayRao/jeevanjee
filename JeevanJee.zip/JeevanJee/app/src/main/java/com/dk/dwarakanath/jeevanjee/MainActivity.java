package com.dk.dwarakanath.jeevanjee;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Integer> imageList = new ArrayList<>();
    private ArrayList<Integer> description = new ArrayList<>();
    private RecyclerView recyclerView;
    private ItemAdapter mAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prepareData();
        init();

    }

    private void init() {
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);

        mAdapter = new ItemAdapter(imageList, description);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(mAdapter);

    }

    private void prepareData() {
        //add images here
        prepareImageList();

        //add descriptions here
        prepareDescriptionList();
    }

    private void prepareDescriptionList() {
        description.add(R.string.image1);
        description.add(R.string.images2);
        description.add(R.string.image11);
        description.add(R.string.image12);
        description.add(R.string.image13);
        description.add(R.string.image14);
        description.add(R.string.image15);
        description.add(R.string.image16);
        description.add(R.string.image17);
        description.add(R.string.image18);
        description.add(R.string.image20);
        description.add(R.string.image21);
        //add further description
    }

    private void prepareImageList() {
        imageList.add(R.drawable.image1);
        imageList.add(R.drawable.images2);
        imageList.add(R.drawable.image11);
        imageList.add(R.drawable.image12);
        imageList.add(R.drawable.image13);
        imageList.add(R.drawable.image14);
        imageList.add(R.drawable.image15);
        imageList.add(R.drawable.image16);
        imageList.add(R.drawable.image17);
        imageList.add(R.drawable.image18);
        imageList.add(R.drawable.image20);
        imageList.add(R.drawable.image21);
        //add further images
    }
}
